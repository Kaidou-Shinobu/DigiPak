# PakEditorAlpha
Pak Editor specialized for the Digimon NDS games

# Usage
Exporting:
./DigiPak [/path/to/file.PAK] 

Import to PAK:
./DigiPak [/dir/to/files/]

Authors:
Kaidou (Primary)
KHeartz