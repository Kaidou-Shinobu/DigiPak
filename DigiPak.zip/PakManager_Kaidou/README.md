Version 1.0.

Usage:

To Export to binary/JSON
./DigiPak [/path/to/file.PAK]

To Import to PAK
./DigiPak [/dir/to/files/]

You can also simply just click and drag the file or directory onto the executable.

Follow the instructions.